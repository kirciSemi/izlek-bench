// Recompute published scores from preserved test outputs; never invokes an API.
import fs from 'node:fs';
import crypto from 'node:crypto';
import {evaluate} from '../dist/scorer.js';
const root = new URL('../', import.meta.url);
const read = p => fs.readFileSync(new URL(p, root));
const dataset = JSON.parse(read('data/benchmark.json'));
const digest = crypto.createHash('sha256').update(read('data/prompts.jsonl')).digest('hex');
const source = process.argv[2] || 'results/raw';
const filenames = ['d7bb7c1fbe96-test-1.json','3f3f5e6154c2-test-1.json','1fbd78dd3fc1-test-1.json'];
const runs = filenames.map(name => {
 const raw = JSON.parse(read(`${source}/${name}`));
 if(raw.prompts_sha256 !== digest || raw.split !== 'test' || raw.responses.length !== 60 || raw.responses.some(r=>r.error)) throw Error('Run integrity failed: '+name);
 const metadata = ['benchmark_version','model','run_type','requested_model','endpoint','parameters','prompts_sha256','split','repetition','started_at'];
 const fields = ['id','response','returned_model','usage','finish_reason','latency_seconds','attempts'];
 const submission = Object.fromEntries(metadata.map(k=>[k,raw[k]]));
 submission.responses = raw.responses.map(r=>Object.fromEntries(fields.filter(k=>k in r).map(k=>[k,r[k]])));
 const score = evaluate(dataset, submission, 'test');
 const diagnostics = {api_responses:raw.responses.length, empty:raw.responses.filter(r=>!r.response).length, length_limited:raw.responses.filter(r=>r.finish_reason==='length').length, format_errors:score.rows.filter(r=>!r.valid).map(r=>({id:r.id,message:r.errors[0].message}))};
 return {filename:name,submission,score,diagnostics};
});
for(const dir of ['results/published','dist/data']) fs.mkdirSync(new URL(dir+'/',root),{recursive:true});
for(const r of runs) fs.writeFileSync(new URL('results/published/'+r.filename,root),JSON.stringify(r.submission,null,2)+'\n');
const release = {date:'2026-11-23',note:'Recorded provider responses; not independently audited. One repetition per model. Empty outputs and strict format failures receive zero credit.',runs};
for(const path of ['results/published/study.json','dist/data/study.json']) fs.writeFileSync(new URL(path,root),JSON.stringify(release,null,2)+'\n');
console.log(runs.map(r=>`${r.score.model}: ${r.score.joint_exact}% joint exact; ${r.score.valid}/60 contract-valid`).join('\n'));
