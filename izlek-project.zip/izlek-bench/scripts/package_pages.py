"""Export a flat static site suitable for GitHub's browser uploader and Pages root."""
from pathlib import Path
import shutil
import zipfile
ROOT=Path(__file__).resolve().parents[1]
out=ROOT/'release/github-pages';out.mkdir(parents=True,exist_ok=True)
for file in (ROOT/'dist').rglob('*'):
    if not file.is_file() or file.name.startswith('.'): continue
    target=out/file.name
    if file.suffix in ['.html','.js','.css']:
        text=file.read_text().replace('downloads/','').replace('data/benchmark.json','benchmark.json').replace('data/study.json','study.json')
        target.write_text(text)
    else: shutil.copyfile(file,target)
(out/'.nojekyll').write_text('')
shutil.copyfile(ROOT/'LICENSE',out/'LICENSE')
(out/'README.md').write_text('''# İZLEK Bench

CMPE/EEEN 566 · Semi KIRCI

A benchmark of valid state updates and source attribution in Turkish dialogues.

- 60 test cases and 12 development cases.
- Three recorded model runs (180 API responses).
- Joint exact: GPT-OSS 120B 90%, Qwen 3.8 27B 88.33%, GPT-OSS 20B 46.67%.
- Academic English report, task-family analysis, strict-format caveats, and reproducible scores.

The complete source, dataset, preserved test responses, tests and report are in `izlek-project.zip`.
This repository serves the prebuilt static interface from the root of `main` using GitHub Pages.
AI assistance is disclosed in the report. Independent human annotation review is not claimed.

Open `index.html` through an HTTP server, not file://. No API key is needed to use the site.
''')
with zipfile.ZipFile(ROOT/'release/github-pages.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(out.iterdir()):z.write(p,p.name)
print('GitHub Pages files:',len(list(out.iterdir())))
