"""Assemble static downloadable artifacts; allowlist prevents secret inclusion."""
import json
from pathlib import Path
import shutil
import zipfile

ROOT=Path(__file__).resolve().parents[1]
dist=ROOT/'dist'; downloads=dist/'downloads'; downloads.mkdir(parents=True,exist_ok=True)
(dist/'data').mkdir(exist_ok=True)
shutil.copyfile(ROOT/'data/benchmark.json',dist/'data/benchmark.json')
for name in ['benchmark.json','prompts.jsonl','submission-template.json','manifest.json']:
    shutil.copyfile(ROOT/'data'/name,downloads/name)
for source,target in [('docs/report.html','dist/report.html'),('docs/izlek-report.pdf','dist/downloads/izlek-report.pdf')]:
    if not (ROOT/source).exists(): raise SystemExit('Missing report; run scripts/build_report.py first: '+source)
    shutil.copyfile(ROOT/source,ROOT/target)
selected=[]
for pattern in ['README.md','LICENSE','package.json','models.example.json','models.groq.json',
                'data/*.json','data/*.jsonl','scripts/*.py','scripts/*.mjs','tests/*.mjs','tests/*.py',
                'docs/*.html','docs/*.pdf','docs/*.json','results/baselines.json','results/published/*.json','docs/*.txt','dist/*.html','dist/*.css','dist/*.js','dist/*.svg','dist/data/*.json']:
    selected.extend(ROOT.glob(pattern))
with zipfile.ZipFile(downloads/'izlek-project.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for file in sorted(set(selected)): archive.write(file,Path('izlek-bench')/file.relative_to(ROOT))
print('Static site assembled; archive contains',len(set(selected)),'allowlisted files.')
