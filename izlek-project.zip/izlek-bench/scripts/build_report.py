"""Generate the same research report as HTML and PDF."""
from pathlib import Path
import html
import json
import os
import re
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak, Table, TableStyle

ROOT=Path(__file__).resolve().parents[1]
baseline=json.loads((ROOT/'results/baselines.json').read_text())['results']
manifest=json.loads((ROOT/'data/manifest.json').read_text())
# Text is authored for this assignment; no existing benchmark items are reused.
pages=json.loads((ROOT/'docs/report-content.en.json').read_text())


def main():
    fonts=[('/System/Library/Fonts/Supplemental/Arial.ttf','/System/Library/Fonts/Supplemental/Arial Bold.ttf'),
           ('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf','/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf')]
    if os.environ.get('IZLEK_FONT_REGULAR'): fonts.insert(0,(os.environ['IZLEK_FONT_REGULAR'],os.environ['IZLEK_FONT_BOLD']))
    pair=next((p for p in fonts if all(Path(f).exists() for f in p)),None)
    if not pair: raise SystemExit('Set IZLEK_FONT_REGULAR and IZLEK_FONT_BOLD to Turkish-capable TTF fonts.')
    pdfmetrics.registerFont(TTFont('Body',pair[0]));pdfmetrics.registerFont(TTFont('Bold',pair[1]))
    styles={
        'title':ParagraphStyle('title',fontName='Bold',fontSize=23,leading=29,spaceAfter=17,textColor=colors.HexColor('#202239')),
        'subtitle':ParagraphStyle('subtitle',fontName='Body',fontSize=13,leading=18,spaceAfter=15),
        'h':ParagraphStyle('h',fontName='Bold',fontSize=11.5,leading=15,spaceBefore=13,spaceAfter=7,keepWithNext=True),
        'p':ParagraphStyle('p',fontName='Body',fontSize=9.4,leading=14.1,spaceAfter=8),
        'cell':ParagraphStyle('cell',fontName='Body',fontSize=8.4,leading=11.5),
        'head':ParagraphStyle('head',fontName='Bold',fontSize=8.4,leading=11.5,textColor=colors.white),
    }
    story=[];html_pages=[]
    for i,page in enumerate(pages):
        if i:story.append(PageBreak())
        story.append(Paragraph(html.escape(page['title']),styles['title']))
        hp='<section><p class="eyebrow">İZLEK BENCH · CMPE / EEEN 566</p><h1>'+html.escape(page['title'])+'</h1>'
        if page.get('subtitle'):story.append(Paragraph(html.escape(page['subtitle']),styles['subtitle']));hp+='<p class="subtitle">'+html.escape(page['subtitle'])+'</p>'
        for kind,value in page['blocks']:
            if kind=='table':
                n=len(value[0]);widths=[170,125,145] if n==3 else [170,90,90,90]
                cells=[[Paragraph(html.escape(str(cell)),styles['head' if ri==0 else 'cell']) for cell in row] for ri,row in enumerate(value)]
                table=Table(cells,colWidths=widths,repeatRows=1,hAlign='LEFT')
                table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#31374e')),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#f4f5f9')]),('GRID',(0,0),(-1,-1),.5,colors.HexColor('#d9d9d9')),('VALIGN',(0,0),(-1,-1),'MIDDLE'),('TOPPADDING',(0,0),(-1,-1),8),('BOTTOMPADDING',(0,0),(-1,-1),8),('LEFTPADDING',(0,0),(-1,-1),8)]))
                story.extend([Spacer(1,4),table,Spacer(1,12)])
                hp+='<div class="table-wrap"><table>'+''.join('<tr>'+''.join(('<th>' if ri==0 else '<td>')+html.escape(str(x))+('</th>' if ri==0 else '</td>') for x in row)+'</tr>' for ri,row in enumerate(value))+'</table></div>'
            else:
                story.append(Paragraph(html.escape(value),styles[kind]));tag='h2' if kind=='h' else 'p'
                txt=html.escape(value)
                txt=re.sub(r'(https://[^\s]+)',r'<a href="\1">\1</a>',txt)
                hp+=f'<{tag}>{txt}</{tag}>'
        html_pages.append(hp+'</section>')
    def footer(canvas,doc):
        canvas.setFont('Body',8);canvas.setFillColor(colors.HexColor('#6b6d7c'))
        canvas.drawString(55,30,'İZLEK Bench 1.0.0 · 23 November 2026');canvas.drawRightString(A4[0]-55,30,str(doc.page))
    ROOT.joinpath('docs').mkdir(exist_ok=True)
    doc=SimpleDocTemplate(str(ROOT/'docs/izlek-report.pdf'),pagesize=A4,rightMargin=55,leftMargin=55,topMargin=42,bottomMargin=48,title='İZLEK Bench: Valid State Updates and Source Attribution in Turkish Dialogues',author='İZLEK Bench')
    doc.build(story,onFirstPage=footer,onLaterPages=footer)
    style='body{font-family:Arial,sans-serif;color:#24283c;background:#f5f6fa;margin:0;line-height:1.7}main{max-width:900px;margin:35px auto;padding:0 20px}section{background:white;padding:38px 46px;margin:20px 0;border:1px solid #e0e3ed;border-radius:10px}h1{font-size:28px;line-height:1.3}h2{font-size:19px;margin-top:28px}p{font-size:15px}.eyebrow{font-size:12px;letter-spacing:1px;color:#5143cc}.subtitle{font-size:20px}a{color:#5143cc;overflow-wrap:anywhere}table{border-collapse:collapse;width:100%;font-size:13px}th,td{padding:10px;border:1px solid #ddd;text-align:left}th{background:#f0f1f7}.table-wrap{overflow:auto}.toolbar{display:flex;gap:20px;align-items:center}button{padding:10px;font-size:14px;cursor:pointer}@media(max-width:600px){section{padding:22px}}@media print{body{background:white}main{margin:0;padding:0;max-width:none}.toolbar{display:none}section{border:0;border-radius:0;margin:0;padding:0;break-after:page}a{color:black}h2{break-after:avoid}}'
    page='<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>İZLEK Bench Research Report</title><style>'+style+'</style></head><body><main><div class="toolbar"><a href="index.html#method">Back to platform</a><a href="downloads/izlek-report.pdf">Download PDF</a><button onclick="window.print()">Print</button></div>'+''.join(html_pages)+'</main></body></html>'
    (ROOT/'docs/report.html').write_text(page)
    (ROOT/'docs/report-content.json').write_text(json.dumps(pages,ensure_ascii=False,indent=2)+'\n')
    print('Generated report PDF and HTML.')


if __name__=='__main__':main()
