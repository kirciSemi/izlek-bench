"""OpenAI-compatible chat-completions runner; no third-party dependencies.

Only prompts.jsonl is loaded: answer keys never reach the inference request.
Credentials are read from named environment variables, never saved.
"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import random
import time
import urllib.error
import urllib.parse
import urllib.request

ROOT = Path(__file__).resolve().parents[1]


def http_error_detail(error, secrets):
    """Bound diagnostics and redact credentials before printing or saving them."""
    raw = error.read(16384).decode('utf-8', errors='replace')
    try:
        body = json.loads(raw)
        detail = body.get('error', body) if isinstance(body, dict) else body
        if isinstance(detail, dict):
            raw = ' | '.join(str(detail[k]) for k in ('code', 'type', 'message') if detail.get(k))
        else:
            raw = str(detail)
    except ValueError:
        pass
    for secret in secrets:
        if secret:
            raw = raw.replace(secret, '[REDACTED]')
    return ' '.join(raw.split())[:1200] or 'No error details returned.'


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--config', default=str(ROOT/'models.example.json'))
    p.add_argument('--split', choices=['dev', 'test'], default='test')
    p.add_argument('--out', default=str(ROOT/'results/raw'))
    p.add_argument('--dry-run', action='store_true')
    p.add_argument('--repetitions', type=int, default=1)
    p.add_argument('--resume', action='store_true')
    p.add_argument('--max-requests', type=int, default=100000)
    args = p.parse_args()
    if args.repetitions < 1: p.error('repetitions must be positive')
    if args.max_requests < 1: p.error('max-requests must be positive')
    config = json.loads(Path(args.config).read_text())
    models = config['models']
    if len({m['label'] for m in models}) != len(models): p.error('Model labels must be unique')
    prompts_file = ROOT/'data/prompts.jsonl'
    prompts_hash = hashlib.sha256(prompts_file.read_bytes()).hexdigest()
    prompts = [json.loads(line) for line in prompts_file.read_text().splitlines()]
    prompts = [c for c in prompts if c['split']==args.split]
    print(f'{len(models)} models x {len(prompts)} cases x {args.repetitions} repetitions = {len(models)*len(prompts)*args.repetitions} requests')
    if args.dry_run:
        print('DRY RUN: No API requests; no model results produced.'); return
    # Validate all credentials and destinations before spending on any model.
    for m in models:
        if 'REPLACE' in m['model']: p.error('Replace model placeholders in the config')
        url = urllib.parse.urlparse(m['endpoint'])
        if url.scheme != 'https' and not (url.scheme=='http' and url.hostname in ['localhost','127.0.0.1','::1']):
            p.error('Use HTTPS except for local inference')
        if url.username or url.password or url.query or url.fragment: p.error('Endpoint must not contain credentials, query or fragment')
        if not m.get('api_key_env') and url.hostname not in ['localhost','127.0.0.1','::1']:
            p.error('Remote endpoints require an API key environment variable')
        if m.get('api_key_env') and not os.environ.get(m['api_key_env']): p.error('Missing environment variable: '+m['api_key_env'])
        if any(k in m.get('parameters',{}) for k in ['messages','model','stream','n']): p.error('Parameters must not override messages/model/stream/n')
    out=Path(args.out); out.mkdir(parents=True, exist_ok=True)
    requests_sent=0
    for m in models:
        for repetition in range(args.repetitions):
            filename = hashlib.sha256(m['label'].encode()).hexdigest()[:12]+f'-{args.split}-{repetition+1}.json'
            dest=out/filename
            if dest.exists() and not args.resume: p.error(f'Refusing to overwrite {dest}; use --resume or choose a new output directory')
            order=list(prompts); random.Random(566+repetition).shuffle(order)
            submission={'benchmark_version':'1.0.0','model':m['label'],'run_type':'api',
                'requested_model':m['model'],'endpoint':m['endpoint'], 'parameters':m.get('parameters',{}),
                'prompts_sha256':prompts_hash, 'split':args.split,'repetition':repetition+1,
                'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(), 'responses':[]}
            if dest.exists():
                previous=json.loads(dest.read_text())
                for key in ['benchmark_version','requested_model','endpoint','parameters','prompts_sha256','split','repetition']:
                    if previous.get(key)!=submission.get(key): p.error('Resume metadata mismatch: '+key)
                submission=previous
            complete_ids={r['id'] for r in submission['responses'] if not r.get('error')}
            for i,c in enumerate(order):
                if c['id'] in complete_ids: continue
                if requests_sent>=args.max_requests:
                    print('Request budget reached; continue later with --resume.'); return
                payload={'model':m['model'],'messages':[{'role':'user','content':c['prompt']}],
                         'stream':False, **m.get('parameters',{})}
                # Identify this API client explicitly instead of urllib's default.
                headers={'Content-Type':'application/json', 'Accept':'application/json',
                         'User-Agent':'izlek-bench/1.0.0'}
                if m.get('api_key_env'): headers['Authorization']='Bearer '+os.environ[m['api_key_env']]
                row={'id':c['id'],'response':'','latency_seconds':None}
                for attempt in range(3):
                    if requests_sent>=args.max_requests:
                        row['error']='Request budget reached'; break
                    interval=float(m.get('interval_seconds',0))
                    if interval>0:
                        # Short sleeps keep long free-tier runs interruptible.
                        until=time.monotonic()+interval
                        while time.monotonic()<until: time.sleep(min(5,max(0,until-time.monotonic())))
                    start=time.monotonic()
                    try:
                        req=urllib.request.Request(m['endpoint'],data=json.dumps(payload).encode(),headers=headers)
                        # Never forward an authorization header to a redirected host.
                        class NoRedirect(urllib.request.HTTPRedirectHandler):
                            def redirect_request(self, req, fp, code, msg, headers, newurl): return None
                        opener=urllib.request.build_opener(NoRedirect)
                        requests_sent+=1
                        with opener.open(req,timeout=120) as response: body=json.load(response)
                        choice=body['choices'][0]
                        row.update(response=choice['message'].get('content') or '',
                                   returned_model=body.get('model'),usage=body.get('usage'),
                                   finish_reason=choice.get('finish_reason'),request_id=body.get('id'),
                                   latency_seconds=round(time.monotonic()-start,3),attempts=attempt+1)
                        break
                    except urllib.error.HTTPError as e:
                        if e.code in [500,502,503,504] and attempt<2: time.sleep(2**attempt); continue
                        row['error']=f'HTTP {e.code}'
                        row['error_detail']=http_error_detail(e, [os.environ.get(model.get('api_key_env', ''), '') for model in models])
                        break
                    except (urllib.error.URLError,TimeoutError) as e:
                        if attempt<2: time.sleep(2**attempt); continue
                        row['error']=type(e).__name__; break
                    except (KeyError,ValueError,IndexError) as e:
                        row['error']='Response schema: '+type(e).__name__; break
                submission['responses']=[r for r in submission['responses'] if r['id']!=c['id']]+[row]
                tmp=dest.with_suffix('.tmp'); tmp.write_text(json.dumps(submission,ensure_ascii=False,indent=2)+'\n'); tmp.replace(dest)
                print(f'{m["label"]} {i+1}/{len(order)} {c["id"]}: '+('error' if row.get('error') else 'received'), flush=True)
                if row.get('error'):
                    print(row['error']+': '+row.get('error_detail', ''), flush=True)
                if row.get('error') in ['HTTP 401','HTTP 403','HTTP 429']:
                    guidance = {'HTTP 401': 'Check the API key.',
                                'HTTP 403': 'Access denied. Check provider details and account/model permissions.',
                                'HTTP 429': 'Rate or quota limit reached. Check provider limits and retry timing.'}
                    print(guidance[row['error']]+' Then retry with --resume.'); return
            print('Saved', dest)


if __name__=='__main__': main()
