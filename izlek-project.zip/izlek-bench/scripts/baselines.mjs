import fs from 'node:fs';
import {evaluate} from '../dist/scorer.js';
const root=new URL('../',import.meta.url);
const dataset=JSON.parse(fs.readFileSync(new URL('data/benchmark.json',root)));
const initialOnly=c=>{
  const text=c.messages[0].text;
  const state={},source={};
  for(const entity of c.entities){
    const marker=entity+': yer ';
    const fragment=text.slice(text.indexOf(marker)+marker.length).split('.')[0];
    const [place, time, channel]=fragment.split(/, saat |, kanal /);
    state[entity]={yer:place,saat:time,kanal:channel};
    source[entity]={yer:'m1',saat:'m1',kanal:'m1'};
  }
  return {durum:state,kaynak:source};
};
const baselineDefs=[['Preserve initial state',initialOnly],['Apply first explicit update',c=>{
  const out=initialOnly(c);
  // Deliberately naive baseline: only the first explicit channel update.
  const m=c.messages[1]; const entity=c.entities.find(n=>m.text.startsWith(n+' için'));
  out.durum[entity].kanal='uygulama';out.kaynak[entity].kanal=m.id;return out;
}]];
const result=[];
for(const [model,fn] of baselineDefs){
  const submission={benchmark_version:dataset.version,model,run_type:'deterministic-baseline',responses:dataset.cases.filter(c=>c.split==='test').map(c=>({id:c.id,response:fn(c)}))};
  result.push(evaluate(dataset,submission));
}
fs.writeFileSync(new URL('results/baselines.json',root),JSON.stringify({notice:'These are not LLMs and do not satisfy the three-model requirement.',results:result},null,2)+'\n');
console.log(result.map(r=>({model:r.model,joint_exact:r.joint_exact,state_accuracy:r.state_accuracy,pair_exact:r.pair_exact})));
