"""Prompt privately for a Groq key and forward arguments to the runner."""
import getpass
import os
from pathlib import Path
import subprocess
import sys


if __name__ == '__main__':
    root = Path(__file__).resolve().parents[1]
    key = getpass.getpass('Groq API anahtarını yapıştır ve Enter’a bas: ').strip()
    if not key:
        sys.exit('Anahtar boş kaldı. Komutu yeniden çalıştır.')
    env = os.environ.copy()
    env['GROQ_API_KEY'] = key
    sys.exit(subprocess.call([
        sys.executable, str(root / 'scripts/run_models.py'),
        '--config', str(root / 'models.groq.json'), *sys.argv[1:],
    ], env=env))
