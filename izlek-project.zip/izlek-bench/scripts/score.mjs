import fs from 'node:fs';
import {evaluate} from '../dist/scorer.js';
const [input, output, split='test'] = process.argv.slice(2);
if (!input) { console.error('Usage: node scripts/score.mjs responses.json [score.json] [test|dev]'); process.exit(1); }
try {
  const dataset=JSON.parse(fs.readFileSync(new URL('../data/benchmark.json',import.meta.url)));
  const result=evaluate(dataset, JSON.parse(fs.readFileSync(input,'utf8')), split);
  const text=JSON.stringify(result,null,2)+'\n';
  if(output) fs.writeFileSync(output,text); else process.stdout.write(text);
  console.error(`${result.model}: joint exact=${result.joint_exact}%, coverage=${result.coverage}%, complete=${result.complete}`);
} catch(e) { console.error(e.message); process.exit(1); }
