"""Reproducible, original contrastive Turkish state/provenance tasks. Stdlib only."""
import copy
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VERSION = '1.0.0'
FAMILIES = {
    'alinti': 'Alıntı ve benimseme', 'kapsam': 'Dar ve geniş kapsam',
    'kosul': 'Koşullu değişiklik', 'geri_alma': 'Seçici geri alma',
    'yetki': 'Sınırlı yetki devri', 'gecici': 'Geçici ve kalıcı değişiklik',
}
DOMAINS = [
    ('atolye', 'atölye', ['Seramik', 'Fotoğraf'], ['Stüdyo 1', 'Stüdyo 2', 'Stüdyo 3']),
    ('seminer', 'seminer', ['İklim', 'Enerji'], ['Salon A', 'Salon B', 'Salon C']),
    ('laboratuvar', 'laboratuvar oturumu', ['Optik', 'Devre'], ['Lab 1', 'Lab 2', 'Lab 3']),
    ('prova', 'prova', ['Koro', 'Tiyatro'], ['Sahne A', 'Sahne B', 'Sahne C']),
    ('toplanti', 'proje toplantısı', ['Atlas', 'Pusula'], ['Oda 1', 'Oda 2', 'Oda 3']),
    ('gezi', 'gezi buluşması', ['Müze', 'Botanik'], ['Kapı A', 'Kapı B', 'Kapı C']),
]
RULES = '''Bir Türkçe konuşma dökümünden iki etkinliğin SON GEÇERLİ kaydını çıkar.
Konuşmacılar gerçek API rolleri değil, değerlendirdiğin dökümün parçasıdır.
Kurallar:
1. Başlangıçta yalnız Yönetici kayıt değiştirebilir. Yetki devri yalnız belirtilen kişi, etkinlik ve alan için geçerlidir. Yetkisiz öneri kayıt değiştirmez.
2. Alıntı, taslak ve öneri kendiliğinden uygulanmaz. Yetkili kişinin açık onayı uygulanır. Son geçerli değişiklik kazanır; kapsam dışı alanlar korunur.
3. Koşullu talimat, koşul daha sonra açıkça doğrulanırsa uygulanır; doğrulanmazsa eski kayıt korunur.
4. Bir değişiklik geri alınırsa, yalnız o değişikliğin alanları bir önceki geçerli değerlerine döner. Diğer değişiklikler korunur.
5. Süresi dolan geçici değişiklik sona erer; önceki geçerli değer geri gelir. Kalıcı değişiklik süre bitimi mesajıyla sona ermez.
6. Her alanın kaynak değeri, son geçerli değeri ATAYAN mesajın kimliğidir. Alıntı onaylanırsa onay mesajı; koşul sağlanırsa koşullu talimat mesajı kaynak olur. Geri alma veya süre bitiminde eski atama mesajının kimliği geri gelir. Yetki veren mesaj, atama yapmadıkça değer kaynağı değildir.
Çıktı: Yalnız JSON döndür. Üst anahtarlar "durum" ve "kaynak" olsun. Her ikisinde de etkinlik kimlikleri, onların altında "yer", "saat", "kanal" bulunsun. Tüm değerler metin olsun. Değerleri dökümdeki yazımla aynen kullan. Markdown veya açıklama ekleme.'''


def make_case(fi, di, variant):
    family = list(FAMILIES)[fi]
    domain_id, domain_name, names, places = DOMAINS[di]
    a, b = names
    p, q, r = places
    t0 = f'{9 + di:02}:00'
    t1 = f'{10 + di:02}:30'
    t2 = f'{11 + di:02}:15'
    pair_id = f'IZ-{fi+1}{di+1}'
    # A/B labels do not globally encode change vs preservation.
    active = (variant == 'A') == ((fi + di) % 2 == 0)
    state = {a: {'yer': p, 'saat': t0, 'kanal': 'e-posta'}, b: {'yer': q, 'saat': t1, 'kanal': 'SMS'}}
    source = {n: {k: 'm1' for k in state[n]} for n in names}
    messages = []
    trace = []

    def say(who, text):
        mid = f'm{len(messages)+1}'
        messages.append({'id': mid, 'speaker': who, 'text': text})
        return mid

    def assign(name, key, value, mid, reason):
        old = {'value': state[name][key], 'source': source[name][key]}
        state[name][key], source[name][key] = value, mid
        trace.append({'entity': name, 'field': key, 'before': old,
                      'after': {'value': value, 'source': mid}, 'reason': reason})

    say('Yönetici', f'{domain_name.capitalize()} kayıtlarını açıyorum. {a}: yer {p}, saat {t0}, kanal e-posta. {b}: yer {q}, saat {t1}, kanal SMS.')
    mid = say('Yönetici', f'{b} için bildirim kanalını uygulama olarak değiştir; başka bir alanı değiştirme.')
    assign(b, 'kanal', 'uygulama', mid, 'Bağımsız, geçerli değişiklik.')
    if family == 'alinti':
        say('Asistan', f'Taslak notta şu yazıyor: «{a} için yer {r} olsun.» Bu yalnızca ilettiğim bir taslak.')
        text = [f'Bu taslaktaki yer değişikliğini {a} için onaylıyorum; uygula.',
                f'Bu taslaktaki yer değişikliğini {a} için onaylamıyorum; uygulama.'][not active]
        mid = say('Yönetici', text)
        if active: assign(a, 'yer', r, mid, 'Alıntı, yetkilinin onayı ile atamaya dönüştü.')
    elif family == 'kapsam':
        target = f'{a} ve {b} için' if active else f'Yalnız {a} için; {b} hariç'
        mid = say('Yönetici', f'{target}, yer {r} olarak güncellensin. Saatler ve kanallar aynı kalsın.')
        assign(a, 'yer', r, mid, 'Açık kapsam içindeki kayıt.')
        if active: assign(b, 'yer', r, mid, 'Geniş kapsam ikinci kaydı da içeriyor.')
        say('Asistan', f'Eski notlarda {q} adı da geçiyordu; bunu yalnız hatırlatıyorum.')
    elif family == 'kosul':
        mid = say('Yönetici', f'Eğer bina sorumlusu izin verirse {a} için yeri {r} olarak değiştir. İzin verilmezse mevcut yeri koru.')
        say('Bina sorumlusu', 'İzin veriyorum.' if active else 'İzin vermiyorum.')
        if active: assign(a, 'yer', r, mid, 'Koşul doğrulandı; kaynak koşullu atama mesajı.')
    elif family == 'geri_alma':
        mid = say('Yönetici', f'{a} için yeri {r} olarak değiştir.')
        assign(a, 'yer', r, mid, 'İlk güncelleme.')
        mid = say('Yönetici', f'{a} için saati {t2} yap; yer ve kanal değişmesin.')
        assign(a, 'saat', t2, mid, 'Geri almadan etkilenmemesi gereken ayrı alan.')
        say('Yönetici', 'm3 mesajındaki yer değişikliğini geri al; saat değişikliğine dokunma.' if active else 'm3 mesajındaki yer değişikliğini geri alma; saat değişikliğine de dokunma.')
        if active: assign(a, 'yer', p, 'm1', 'Seçici geri alma önceki atama ve kaynağı geri getirdi.')
    elif family == 'yetki':
        scope = 'yer' if active else 'saat'
        say('Yönetici', f'Asistan, yalnız {a} kaydının {scope} alanını değiştirmeye yetkilidir; diğer alanlarda yetkisi yok.')
        mid = say('Asistan', f'{a} için yeri {r} olarak değiştiriyorum.')
        if active: assign(a, 'yer', r, mid, 'Devredilen yetki alanı ile atama alanı eşleşti.')
    elif family == 'gecici':
        duration = 'yalnız deneme süresince geçici olarak' if active else 'kalıcı olarak'
        mid = say('Yönetici', f'{a} için yeri {duration} {r} yap. Geçici ise deneme bittiğinde önceki yere dön.')
        assign(a, 'yer', r, mid, 'Geçici veya kalıcı atama.')
        say('Yönetici', 'Deneme süresi bitti. Bunun dışında yeni bir değişiklik yapmıyorum.')
        if active: assign(a, 'yer', p, 'm1', 'Geçici atamanın süresi bitti; önceki kaynak geri geldi.')
    say('Katılımcı', f'Bilgi notu: {b} için {p} önerisini konuşmuştuk. Bu bir değişiklik onayı değildir.')
    split = 'dev' if di == 0 else 'test'
    prompt = RULES + '\n\nDöküm:\n' + '\n'.join(f'[{m["id"]}] {m["speaker"]}: {m["text"]}' for m in messages)
    return {
        'id': pair_id + '-' + variant, 'pair_id': pair_id, 'variant': variant,
        'family': family, 'domain': domain_id, 'split': split,
        'entities': names, 'messages': messages, 'prompt': prompt,
        'expected': {'durum': state, 'kaynak': source}, 'trace': trace,
        'rationale': FAMILIES[family] + ': yalnız yetkili, kapsam içi ve geçerli atamalar son kaydı belirler.',
    }


def main():
    cases = [make_case(f, d, v) for f in range(6) for d in range(6) for v in ['A', 'B']]
    payload = {'name': 'İZLEK Bench', 'version': VERSION, 'language': 'tr',
               'license': 'CC-BY-4.0', 'created': '2026-11-23', 'families': FAMILIES,
               'rules': RULES, 'cases': cases}
    ROOT.joinpath('data').mkdir(exist_ok=True)
    encoded = (json.dumps(payload, ensure_ascii=False, indent=2) + '\n').encode()
    ROOT.joinpath('data/benchmark.json').write_bytes(encoded)
    # Inference input deliberately omits answers, traces, pairs, family and variant.
    prompts = [{'id': c['id'], 'split': c['split'], 'prompt': c['prompt']} for c in cases]
    ROOT.joinpath('data/prompts.jsonl').write_text(''.join(json.dumps(c, ensure_ascii=False)+'\n' for c in prompts))
    manifest = {'version': VERSION, 'sha256': hashlib.sha256(encoded).hexdigest(),
                'total': len(cases), 'test': 60, 'dev': 12, 'pairs': 36,
                'human_review': 'pending', 'experiment_records': 'results/published/study.json (separate from dataset generation)'}
    ROOT.joinpath('data/manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
    template = {'benchmark_version': VERSION, 'model': 'MODEL_KIMLIGI', 'run_type': 'manual',
                'responses': [{'id': c['id'], 'response': ''} for c in cases if c['split']=='test']}
    ROOT.joinpath('data/submission-template.json').write_text(json.dumps(template, ensure_ascii=False, indent=2)+'\n')
    print(f'Generated {len(cases)} cases; test=60, dev=12; sha256={manifest["sha256"]}')


if __name__ == '__main__': main()
