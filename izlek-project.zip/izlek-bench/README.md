# İZLEK Bench

A controlled benchmark of valid state updates and source attribution in Turkish task dialogues, developed for CMPE/EEEN 566.

**Study status:** three LLMs completed 60 test calls each on 23 November 2026. The release contains recorded responses, reproducible scores, comparative error analysis, and an academic English report. Independent human annotation review remains pending. AI assistance is disclosed in the report.

Author: Semi KIRCI. Course: CMPE/EEEN 566.

Deployment target: GitHub Pages. The static `dist/` directory can be served on any static host. The final public URL is recorded in `docs/deployment.txt` after deployment is verified.

## Quick start

Python 3.9+ and Node.js 18+ are required. The static interface has no npm dependencies.

```sh
python3 scripts/generate_dataset.py
npm test
node scripts/baselines.mjs
python3 scripts/build.py
npm run preview
```

Open http://localhost:8766 rather than opening index.html through file://.
The PDF report is included. To regenerate it, use a Python environment with reportlab and run `python3 scripts/build_report.py`. The English report source is `docs/report-content.en.json`. If a suitable font is not found, set `IZLEK_FONT_REGULAR` and `IZLEK_FONT_BOLD` to Turkish-capable TTF font paths.

## Language policy

The interface, report, and project documentation are in English. Experimental dialogues remain in Turkish because Turkish language understanding is the target construct. The JSON keys `durum` (state), `kaynak` (source), `yer` (location), `saat` (time), and `kanal` (notification channel) are retained as part of the experimental contract. Presentation-language changes do not change the benchmark version or dataset hash.

## Models versus providers

Groq is an inference provider. It is not itself one of the LLMs evaluated. `models.groq.json` defines three distinct model IDs: GPT-OSS 20B, GPT-OSS 120B, and Qwen 3.8 27B, all served through Groq. The two GPT-OSS variants share a family; the configuration does not represent three independent model families. Availability and account quotas must be verified before execution. All three were evaluated in the recorded study; returned model identifiers matched the configuration.

The assignment requires at least three different LLMs; it does not specify three different API providers.

## Running actual experiments

The website evaluates submitted responses locally in the browser. It does not call model APIs or request API keys. Uploaded files are not sent to a server; session results are cleared when the page is closed or reloaded.

To set a key for a single macOS zsh session without displaying it or placing it in shell history:

```sh
read -s 'GROQ_API_KEY?Groq API key: '
export GROQ_API_KEY
python3 scripts/run_models.py --config models.groq.json --split dev --dry-run
python3 scripts/run_models.py --config models.groq.json --split dev
python3 scripts/run_models.py --config models.groq.json --split test
unset GROQ_API_KEY
```

The runner sends one case per independent request. It reads only prompts.jsonl: answer keys, operation traces, pair labels, and family labels are not sent to the model. All models receive the same prompts. JSON-mode and tools are disabled; format compliance is evaluated. The runner records parameters and the model identifier returned by the provider. A temperature setting of zero does not guarantee fully deterministic generation, and equal token limits do not imply equal computation across families.

After a quota interruption, repeat the same command with `--resume`. Successful responses are not regenerated; transport failures can be retried. `--max-requests 40` limits the total number of network requests for that invocation, including retries. HTTP 401, 403, or 429 stops execution after saving progress. Do not selectively regenerate successful but incorrect answers. If using repetitions, decide on `--repetitions 3` before testing and report every repetition.

Raw runs are written to `results/raw/`, which is excluded from Git and publication packages. The reviewed publication allowlist copies test response contents, usage, timing, and model metadata into `results/published/`; credentials and provider request identifiers are not copied. Reproduce published scores without API calls using `node scripts/publish_results.mjs results/published`. Score each run with:

```sh
node scripts/score.mjs results/raw/RUN.json results/score.json test
```

For manual experiments, submit each test prompt from `data/prompts.jsonl` in a fresh conversation and record the raw output in `data/submission-template.json`. Record the visible model version and execution date. Disable memory and external tools where possible. Manual and API conditions are not necessarily equivalent and should be reported separately.

## Design and scoring

- Six task families × six contexts × two variants = 72 cases.
- Development: 12 workshop cases. Test: 60 cases in five other contexts.
- Both members of each contrastive pair remain in the same split. A/B labels do not consistently encode update direction.
- Primary metric: percentage of cases with all six values and six sources correct.
- Secondary metrics: value accuracy, source accuracy, joint field accuracy, state exact accuracy, pair accuracy, coverage, format validity, and per-family scores.
- Missing responses are not removed from the denominator. The main test denominator is always 60.
- Exploratory 95% intervals use 2,000 within-family, pair-level bootstrap samples. Thirty pairs are not thirty independent template families.
- `results/baselines.json` reports deterministic non-LLM baselines. These do not satisfy the requirement to evaluate three LLMs.

## Assignment completion checklist

| Requirement | Current status |
| --- | --- |
| Original benchmark with a specific research question | Designed; the narrow originality argument requires critical review |
| At least 50 annotated cases | 60 test cases and 12 development cases |
| Three actual LLM evaluations and comparison | Completed: 180 API responses, strict scores and error analysis |
| Response submission and scoring interface | Implemented |
| Public hosting | Portable static release; see docs/deployment.txt for verified URL |
| Report, dataset, source code, and methodology | Available with recorded empirical results |

Before submission, review the Turkish scenarios and attribution policy, the recorded model errors, and the course AI-use rules. No independent human review is claimed. Do not change labels or selectively regenerate failed-content cases after viewing results. The report documents the five 20B development connection checks and the absence of a complete development study.

## Recorded test results

| Model | Joint exact | Pair exact | Contract valid |
| --- | --- | --- | --- |
| GPT-OSS 20B | 28/60 (46.67%) | 5/30 (16.67%) | 35/60 |
| GPT-OSS 120B | 54/60 (90.00%) | 25/30 (83.33%) | 60/60 |
| Qwen 3.8 27B | 53/60 (88.33%) | 23/30 (76.67%) | 60/60 |

Twenty-three 20B outputs contain decorated source identifiers; two more terminate at the token limit (one empty and one truncated). The strict original scorer is preserved. The one-case gap between the leading models does not demonstrate reliable superiority. See the report for per-family results, hypotheses, and limitations.

## Repository layout

- `data/`: annotated benchmark, prompts-only inputs, integrity manifest, submission template.
- `dist/`: static web platform and shared JavaScript scorer.
- `scripts/`: generation, API execution, CLI scoring, baselines, report generation, packaging.
- `tests/`: dataset/scoring contracts and mocked API transport tests.
- `docs/`: English HTML/PDF report and source content.

## References and licensing

The report includes related work and citations. Dataset and report: CC BY 4.0. Code: MIT. No existing benchmark items were copied. The contribution is a narrowly scoped task design; this project does not claim to be the first evaluation of state tracking or Turkish instruction following.

API protocol: https://developers.openai.com/api/reference/resources/chat/subresources/completions/methods/create

Provider documentation: https://console.groq.com/docs/openai and https://console.groq.com/docs/rate-limits
