"""Offline mock HTTP transport tests; these are NOT LLM evaluations."""
import importlib.util
import io
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('runner',ROOT/'scripts/run_models.py')
runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)


class TransportTest(unittest.TestCase):
    def test_http_diagnostics_redact_key(self):
        body = json.dumps({'error': {'code': 'model_permission_blocked', 'message': 'Denied dummy-secret'}}).encode()
        error = runner.urllib.error.HTTPError('https://example.invalid', 403, 'Forbidden', {}, io.BytesIO(body))
        detail = runner.http_error_detail(error, ['dummy-secret'])
        self.assertIn('model_permission_blocked', detail)
        self.assertIn('[REDACTED]', detail)
        self.assertNotIn('dummy-secret', detail)

    def test_plain_http_diagnostics_are_bounded(self):
        error = runner.urllib.error.HTTPError('https://example.invalid', 403, 'Forbidden', {}, io.BytesIO(b'error code: 1010 ' * 1000))
        detail = runner.http_error_detail(error, [])
        self.assertIn('error code: 1010', detail)
        self.assertLessEqual(len(detail), 1200)

    def test_request_is_prompt_only_and_resume_does_not_repeat(self):
        calls=[]
        class FakeOpener:
            def open(self,req,timeout):
                assert req.get_header('User-agent') == 'izlek-bench/1.0.0'
                assert req.get_header('Accept') == 'application/json'
                calls.append(json.loads(req.data))
                return io.StringIO(json.dumps({'model':'mock-only','id':'test-id','choices':[{'message':{'content':'{}'},'finish_reason':'stop'}],'usage':{'total_tokens':1}}))
        with tempfile.TemporaryDirectory() as temp:
            base=Path(temp);config=base/'models.json';out=base/'out'
            config.write_text(json.dumps({'models':[{'label':'Transport test','model':'mock-only','endpoint':'http://localhost:9999/v1/chat/completions','api_key_env':'IZLEK_TEST_KEY','parameters':{'max_completion_tokens':30}}]}))
            argv=['runner','--config',str(config),'--split','dev','--out',str(out),'--max-requests','2']
            with patch.dict(os.environ,{'IZLEK_TEST_KEY':'dummy-unit-test-only'}),patch.object(sys,'argv',argv),patch.object(runner.urllib.request,'build_opener',return_value=FakeOpener()):runner.main()
            self.assertEqual(len(calls),2)
            for call in calls:
                self.assertEqual(len(call['messages']),1);self.assertEqual(call['messages'][0]['role'],'user')
                self.assertNotIn('expected',call['messages'][0]['content']);self.assertNotIn('trace',call['messages'][0]['content'])
                self.assertEqual(set(call),{'model','messages','stream','max_completion_tokens'})
            saved=next(out.glob('*.json'));before=json.loads(saved.read_text())
            self.assertEqual(len(before['responses']),2);self.assertNotIn('dummy-unit-test-only',saved.read_text())
            with patch.dict(os.environ,{'IZLEK_TEST_KEY':'dummy-unit-test-only'}),patch.object(sys,'argv',argv+['--resume']),patch.object(runner.urllib.request,'build_opener',return_value=FakeOpener()):runner.main()
            after=json.loads(saved.read_text());self.assertEqual(len(after['responses']),4)
            self.assertEqual(len({r['id'] for r in after['responses']}),4)
            self.assertEqual(after['responses'][:2],before['responses'])

    def test_dry_run_never_requests_network(self):
        with patch.object(sys,'argv',['runner','--dry-run']),patch.object(runner.urllib.request,'build_opener') as network:
            runner.main();network.assert_not_called()


if __name__=='__main__':unittest.main()
