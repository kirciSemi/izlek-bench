import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {scoreCase,evaluate,parseResponse} from '../dist/scorer.js';
const d=JSON.parse(fs.readFileSync(new URL('../data/benchmark.json',import.meta.url)));
const clone=x=>JSON.parse(JSON.stringify(x));
const golden={benchmark_version:d.version,model:'Oracle — self-test, NOT an LLM',run_type:'oracle-self-test',responses:d.cases.map(c=>({id:c.id,response:c.expected}))};
test('72 unique cases, 60 test + 12 dev, 6 families and pair-preserving splits',()=>{
 assert.equal(d.cases.length,72);assert.equal(new Set(d.cases.map(c=>c.id)).size,72);
 assert.equal(d.cases.filter(c=>c.split==='test').length,60);
 for(const family of Object.keys(d.families)) assert.equal(d.cases.filter(c=>c.family===family && c.split==='test').length,10);
 for(const c of d.cases){const pair=d.cases.filter(x=>x.pair_id===c.pair_id);assert.equal(pair.length,2);assert.equal(pair[0].split,pair[1].split);assert.notDeepEqual(pair[0].expected,pair[1].expected);
  const changes=pair[0].messages.filter((m,i)=>m.text!==pair[1].messages[i].text);assert.equal(changes.length,1);
 }
});
test('hand-written independent checks: quotation, scope, conditional, rollback, authority, expiry',()=>{
 const get=id=>d.cases.find(c=>c.id===id).expected;
 assert.equal(get('IZ-11-A').durum.Seramik.yer,'Stüdyo 3');assert.equal(get('IZ-11-A').kaynak.Seramik.yer,'m4');
 assert.equal(get('IZ-11-B').durum.Seramik.yer,'Stüdyo 1');
 assert.equal(get('IZ-21-A').durum.Fotoğraf.yer,'Stüdyo 2');assert.equal(get('IZ-21-B').durum.Fotoğraf.yer,'Stüdyo 3');
 assert.equal(get('IZ-31-A').kaynak.Seramik.yer,'m3');assert.equal(get('IZ-31-B').kaynak.Seramik.yer,'m1');
 assert.equal(get('IZ-41-B').durum.Seramik.yer,'Stüdyo 1');assert.equal(get('IZ-41-B').durum.Seramik.saat,'11:15');assert.equal(get('IZ-41-B').kaynak.Seramik.saat,'m4');
 assert.equal(get('IZ-51-A').kaynak.Seramik.yer,'m4');assert.equal(get('IZ-51-B').kaynak.Seramik.yer,'m1');
 assert.equal(get('IZ-61-B').kaynak.Seramik.yer,'m1');assert.equal(get('IZ-61-A').kaynak.Seramik.yer,'m3');
});
test('all expected answers score perfectly as objects AND raw JSON',()=>{
 for(const c of d.cases){assert.equal(scoreCase(c,c.expected).joint_exact,true);assert.equal(scoreCase(c,JSON.stringify(c.expected)).joint_exact,true);}
 const r=evaluate(d,golden);assert.equal(r.joint_exact,100);assert.equal(r.pair_exact,100);assert.deepEqual(r.ci95_joint_exact,[100,100]);
});
test('source-only errors remain visible and break joint exact',()=>{
 const c=d.cases[0],bad=clone(c.expected);bad.kaynak.Seramik.yer='m1';const r=scoreCase(c,bad);
 assert.equal(r.state_exact,true);assert.equal(r.joint_exact,false);assert.equal(r.source_correct,5);
});
test('wrong entity, invalid source, extra keys, arrays, fences, duplicate keys rejected',()=>{
 const c=d.cases[0];for(const bad of [[],null,'```json\n'+JSON.stringify(c.expected)+'\n```',{...c.expected,x:1}]) assert.equal(scoreCase(c,bad).valid,false);
 const bad=clone(c.expected);bad.kaynak.Seramik.yer='m999';assert.equal(scoreCase(c,bad).valid,false);
 const duplicate=JSON.stringify(c.expected).replace('"yer":','"yer":"wrong","yer":');assert.equal(scoreCase(c,duplicate).valid,false);
});
test('missing cases are zero, never silently removed from denominator',()=>{
 const r=evaluate(d,{...golden,responses:[]});assert.equal(r.n,60);assert.equal(r.coverage,0);assert.equal(r.joint_exact,0);assert.equal(r.complete,false);
 const one=d.cases.find(c=>c.split==='test');const s=evaluate(d,{...golden,responses:[{id:one.id,response:one.expected}]});assert.equal(s.joint_exact,1.67);assert.equal(s.pair_exact,0);
});
test('duplicate/unknown IDs, incorrect version, invalid split rejected',()=>{
 assert.throws(()=>evaluate(d,{...golden,responses:[golden.responses[0],golden.responses[0]]}));
 assert.throws(()=>evaluate(d,{...golden,responses:[{id:'unknown',response:{}}]}));
 assert.throws(()=>evaluate(d,{...golden,benchmark_version:'2'}));assert.throws(()=>evaluate(d,golden,'all'));
});
test('one failed member invalidates exactly one complete pair',()=>{
 const s=clone(golden);const c=d.cases.find(c=>c.split==='test');s.responses.find(r=>r.id===c.id).response='invalid';
 const r=evaluate(d,s);assert.equal(r.joint_exact,98.33);assert.equal(r.pair_exact,96.67);assert.equal(r.format_rate,98.33);
});
test('NFC and outer whitespace tolerated but case changes are not',()=>{
 const c=d.cases[0],x=clone(c.expected);x.durum.Seramik.yer=' '+x.durum.Seramik.yer.normalize('NFD')+' ';
 assert.equal(scoreCase(c,x).joint_exact,true);x.durum.Seramik.yer=x.durum.Seramik.yer.toUpperCase();assert.equal(scoreCase(c,x).joint_exact,false);
});
